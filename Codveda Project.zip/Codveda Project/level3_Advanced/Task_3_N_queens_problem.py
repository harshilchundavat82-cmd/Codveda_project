def print_board(board, n):
    for row in board:
        print(" ".join(row))
    print()


def is_safe(board, row, col, n):
    
    for i in range(row):
        if board[i][col] == 'Q':
            return False

    i, j = row - 1, col - 1
    while i >= 0 and j >= 0:
        if board[i][j] == 'Q':
            return False
        i -= 1
        j -= 1

    i, j = row - 1, col + 1
    while i >= 0 and j < n:
        if board[i][j] == 'Q':
            return False
        i -= 1
        j += 1

    return True


def solve_nqueens(board, row, n):
    if row == n:
        print("Solution Found:")
        print_board(board, n)
        return True

    for col in range(n):
        if is_safe(board, row, col, n):
            board[row][col] = 'Q'

            if solve_nqueens(board, row + 1, n):
                return True

            board[row][col] = '.'

    return False


def main():
    n = int(input("Enter the value of N: "))

    board = [['.' for _ in range(n)] for _ in range(n)]

    if not solve_nqueens(board, 0, n):
        print("No solution exists.")


if __name__ == "__main__":
    main()