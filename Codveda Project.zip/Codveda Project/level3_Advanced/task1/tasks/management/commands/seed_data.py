"""
Management command to create demo users and tasks for development.

Usage:
    python manage.py seed_data
"""

from django.core.management.base import BaseCommand
from django.utils import timezone
from datetime import timedelta

from accounts.models import CustomUser
from tasks.models import Task


class Command(BaseCommand):
    help = 'Seed the database with demo admin and regular-user accounts plus sample tasks.'

    def handle(self, *args, **options):
        # Create admin user
        admin, created = CustomUser.objects.get_or_create(
            username='admin_demo',
            defaults={
                'email': 'admin@demo.com',
                'role': CustomUser.Role.ADMIN,
                'is_staff': True,
            }
        )
        if created:
            admin.set_password('Admin@123')
            admin.save()
            self.stdout.write(self.style.SUCCESS('Created admin user: admin_demo / Admin@123'))
        else:
            self.stdout.write('Admin user already exists.')

        # Create regular user
        regular, created = CustomUser.objects.get_or_create(
            username='user_demo',
            defaults={
                'email': 'user@demo.com',
                'role': CustomUser.Role.REGULAR_USER,
            }
        )
        if created:
            regular.set_password('User@123')
            regular.save()
            self.stdout.write(self.style.SUCCESS('Created regular user: user_demo / User@123'))
        else:
            self.stdout.write('Regular user already exists.')

        # Seed sample tasks for regular user
        sample_tasks = [
            {
                'title': 'Set up development environment',
                'description': 'Install Python, Django, and configure the database.',
                'priority': Task.Priority.HIGH,
                'status': Task.Status.COMPLETED,
                'due_date': timezone.now().date() - timedelta(days=2),
            },
            {
                'title': 'Write unit tests',
                'description': 'Cover models, views, and forms with tests.',
                'priority': Task.Priority.MEDIUM,
                'status': Task.Status.IN_PROGRESS,
                'due_date': timezone.now().date() + timedelta(days=3),
            },
            {
                'title': 'Deploy to production',
                'description': 'Set up cloud server, configure nginx and gunicorn.',
                'priority': Task.Priority.HIGH,
                'status': Task.Status.PENDING,
                'due_date': timezone.now().date() + timedelta(days=7),
            },
            {
                'title': 'Review pull requests',
                'description': 'Review and merge open PRs on GitHub.',
                'priority': Task.Priority.LOW,
                'status': Task.Status.PENDING,
                'due_date': None,
            },
        ]

        for data in sample_tasks:
            task, created = Task.objects.get_or_create(
                owner=regular,
                title=data['title'],
                defaults=data,
            )
            if created:
                self.stdout.write(f'  Created task: {task.title}')

        self.stdout.write(self.style.SUCCESS('\nSeed complete! Run the dev server and log in.'))
