from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.core.exceptions import PermissionDenied
from django.shortcuts import render, redirect, get_object_or_404

from accounts.models import CustomUser
from .forms import TaskForm
from .models import Task
from .permissions import admin_required


@login_required
def dashboard(request):
    """Personal task dashboard – shows only the logged-in user's tasks."""
    tasks = Task.objects.filter(owner=request.user)

    # Simple filter by status via query param
    status_filter = request.GET.get('status', '')
    if status_filter:
        tasks = tasks.filter(status=status_filter)

    context = {
        'tasks': tasks,
        'status_filter': status_filter,
        'task_statuses': Task.Status.choices,
        'pending_count': Task.objects.filter(owner=request.user, status=Task.Status.PENDING).count(),
        'in_progress_count': Task.objects.filter(owner=request.user, status=Task.Status.IN_PROGRESS).count(),
        'completed_count': Task.objects.filter(owner=request.user, status=Task.Status.COMPLETED).count(),
    }
    return render(request, 'tasks/dashboard.html', context)


@login_required
def task_create(request):
    """Create a new task for the current user."""
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            task = form.save(commit=False)
            task.owner = request.user
            task.save()
            messages.success(request, f'Task "{task.title}" created.')
            return redirect('tasks:dashboard')
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = TaskForm()

    return render(request, 'tasks/task_form.html', {'form': form, 'action': 'Create'})


@login_required
def task_detail(request, pk):
    """View details of a single task."""
    task = get_object_or_404(Task, pk=pk)
    # Admins can see any task; regular users only their own
    if not request.user.is_app_admin and task.owner != request.user:
        raise PermissionDenied
    return render(request, 'tasks/task_detail.html', {'task': task})


@login_required
def task_update(request, pk):
    """Edit an existing task."""
    task = get_object_or_404(Task, pk=pk)
    if not request.user.is_app_admin and task.owner != request.user:
        raise PermissionDenied

    if request.method == 'POST':
        form = TaskForm(request.POST, instance=task)
        if form.is_valid():
            form.save()
            messages.success(request, f'Task "{task.title}" updated.')
            return redirect('tasks:task_detail', pk=task.pk)
        else:
            messages.error(request, 'Please correct the errors below.')
    else:
        form = TaskForm(instance=task)

    return render(request, 'tasks/task_form.html', {'form': form, 'task': task, 'action': 'Update'})


@login_required
def task_delete(request, pk):
    """Delete a task (POST only)."""
    task = get_object_or_404(Task, pk=pk)
    if not request.user.is_app_admin and task.owner != request.user:
        raise PermissionDenied

    if request.method == 'POST':
        title = task.title
        task.delete()
        messages.success(request, f'Task "{title}" deleted.')
        return redirect('tasks:dashboard')

    return render(request, 'tasks/task_confirm_delete.html', {'task': task})


# ---------------------------------------------------------------------------
# Admin-only views
# ---------------------------------------------------------------------------

@login_required
@admin_required
def admin_dashboard(request):
    """Admin view: list all users and their task counts."""
    users = CustomUser.objects.prefetch_related('tasks').all().order_by('username')
    all_tasks = Task.objects.select_related('owner').all()

    status_filter = request.GET.get('status', '')
    user_filter = request.GET.get('user', '')

    if status_filter:
        all_tasks = all_tasks.filter(status=status_filter)
    if user_filter:
        all_tasks = all_tasks.filter(owner__username__icontains=user_filter)

    context = {
        'users': users,
        'all_tasks': all_tasks,
        'status_filter': status_filter,
        'user_filter': user_filter,
        'task_statuses': Task.Status.choices,
        'total_tasks': Task.objects.count(),
        'total_users': CustomUser.objects.count(),
    }
    return render(request, 'tasks/admin_dashboard.html', context)
