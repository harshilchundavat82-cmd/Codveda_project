from django.contrib import admin
from .models import Task


@admin.register(Task)
class TaskAdmin(admin.ModelAdmin):
    list_display = ('title', 'owner', 'priority', 'status', 'due_date', 'is_overdue', 'created_at')
    list_filter = ('status', 'priority', 'owner')
    search_fields = ('title', 'description', 'owner__username')
    date_hierarchy = 'created_at'
    ordering = ('-created_at',)
