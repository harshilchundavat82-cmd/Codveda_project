from django.core.exceptions import PermissionDenied
from functools import wraps

from accounts.models import CustomUser


def admin_required(view_func):
    """Decorator that restricts a view to app-level admins."""
    @wraps(view_func)
    def _wrapped(request, *args, **kwargs):
        if not request.user.is_authenticated or not request.user.is_app_admin:
            raise PermissionDenied
        return view_func(request, *args, **kwargs)
    return _wrapped
