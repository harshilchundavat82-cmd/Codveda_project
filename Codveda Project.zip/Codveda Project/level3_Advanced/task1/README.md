# TaskManager – Django Web Application with Authentication

A fully functional task-manager built with Django, demonstrating:

- **User registration & login** – backed by Django's PBKDF2 password hashing
- **Logout** – CSRF-protected POST logout
- **Role-based access control** – `Admin` and `Regular User` roles
- **Password reset via email** – 4-step flow using Django's built-in HMAC-signed tokens
- **Admin dashboard** – admins can view and manage all users' tasks
- **Crispy-Bootstrap 5** styled forms throughout

---

## Quick Start

### 1. Create & activate a virtual environment

```bash
python -m venv venv
# Windows
venv\Scripts\activate
# macOS/Linux
source venv/bin/activate
```

### 2. Install dependencies

```bash
pip install -r requirements.txt
```

### 3. Configure environment

```bash
cp .env.example .env
# Edit .env – set SECRET_KEY and email settings
```

### 4. Run migrations

```bash
python manage.py migrate
```

### 5. Seed demo data (optional)

```bash
python manage.py seed_data
# Creates:
#   admin_demo / Admin@123  (role: Admin)
#   user_demo  / User@123   (role: Regular User)
```

### 6. Start the development server

```bash
python manage.py runserver
```

Visit http://127.0.0.1:8000

---

## URL Map

| Path | Description |
|------|-------------|
| `/` | Task dashboard (login required) |
| `/tasks/new/` | Create a task |
| `/tasks/<pk>/` | Task detail |
| `/tasks/<pk>/edit/` | Edit a task |
| `/tasks/<pk>/delete/` | Delete a task |
| `/admin-dashboard/` | Admin-only dashboard |
| `/accounts/register/` | Register |
| `/accounts/login/` | Login |
| `/accounts/logout/` | Logout |
| `/accounts/profile/` | Edit profile |
| `/accounts/password-reset/` | Request password reset email |
| `/admin/` | Django admin site |

---

## Email Configuration

In **development** the default backend prints emails to the console:

```
EMAIL_BACKEND=django.core.mail.backends.console.EmailBackend
```

For **production** with Gmail, switch to SMTP and provide credentials in `.env`:

```
EMAIL_BACKEND=django.core.mail.backends.smtp.EmailBackend
EMAIL_HOST=smtp.gmail.com
EMAIL_PORT=587
EMAIL_USE_TLS=True
EMAIL_HOST_USER=you@gmail.com
EMAIL_HOST_PASSWORD=your-app-password
```

---

## Role Permissions

| Feature | Regular User | Admin |
|---------|-------------|-------|
| Create / edit / delete own tasks | ✅ | ✅ |
| View own tasks | ✅ | ✅ |
| View all users' tasks | ❌ | ✅ |
| Admin dashboard | ❌ | ✅ |
| Django `/admin/` site | ❌ | ✅ |

---

## Project Structure

```
taskmanager/
├── manage.py
├── requirements.txt
├── .env.example
├── taskmanager/          # Django project package
│   ├── settings.py
│   ├── urls.py
│   └── wsgi.py
├── accounts/             # Auth app
│   ├── models.py         # CustomUser with Role enum
│   ├── forms.py          # Registration, Login, Profile, PasswordReset
│   ├── views.py          # register, login, logout, profile, password-reset flow
│   ├── urls.py
│   └── admin.py
├── tasks/                # Task manager app
│   ├── models.py         # Task with Priority/Status enums
│   ├── forms.py
│   ├── views.py          # CRUD + admin dashboard
│   ├── permissions.py    # @admin_required decorator
│   ├── urls.py
│   └── management/commands/seed_data.py
└── templates/
    ├── base.html
    ├── accounts/         # register, login, logout, profile, password-reset (4 templates)
    │   └── emails/       # plain-text + HTML email templates
    └── tasks/            # dashboard, form, detail, delete, admin_dashboard
```
