from django import forms
from django.contrib.auth.forms import (
    UserCreationForm,
    AuthenticationForm,
    PasswordResetForm,
    SetPasswordForm,
)
from django.core.exceptions import ValidationError

from .models import CustomUser


class RegistrationForm(UserCreationForm):

    email = forms.EmailField(
        required=True,
        help_text='A valid email address is required for password resets.',
    )
    role = forms.ChoiceField(
        choices=CustomUser.Role.choices,
        initial=CustomUser.Role.REGULAR_USER,
    )

    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'role', 'password1', 'password2')

    def clean_email(self):
        """Ensure no duplicate email addresses."""
        email = self.cleaned_data.get('email')
        if CustomUser.objects.filter(email=email).exists():
            raise ValidationError('A user with this email already exists.')
        return email

    def save(self, commit=True):
        user = super().save(commit=False)
        user.email = self.cleaned_data['email']
        user.role = self.cleaned_data['role']

        if user.role == CustomUser.Role.ADMIN:
            user.is_staff = True
        if commit:
            user.save()
        return user


class LoginForm(AuthenticationForm):
    
    username = forms.CharField(
        widget=forms.TextInput(attrs={'autofocus': True, 'placeholder': 'Username'})
    )
    password = forms.CharField(
        widget=forms.PasswordInput(attrs={'placeholder': 'Password'})
    )


class ProfileUpdateForm(forms.ModelForm):
    
    class Meta:
        model = CustomUser
        fields = ('username', 'email', 'bio', 'avatar')
        widgets = {
            'bio': forms.Textarea(attrs={'rows': 4}),
        }

    def clean_email(self):
        email = self.cleaned_data.get('email')
        qs = CustomUser.objects.filter(email=email).exclude(pk=self.instance.pk)
        if qs.exists():
            raise ValidationError('A user with this email already exists.')
        return email


class CustomPasswordResetForm(PasswordResetForm):
    

    email = forms.EmailField(
        label='Email address',
        max_length=254,
        widget=forms.EmailInput(attrs={'placeholder': 'Enter your registered email'}),
    )


class CustomSetPasswordForm(SetPasswordForm):
   
    new_password1 = forms.CharField(
        label='New password',
        widget=forms.PasswordInput(attrs={'placeholder': 'New password'}),
        strip=False,
    )
    new_password2 = forms.CharField(
        label='Confirm new password',
        widget=forms.PasswordInput(attrs={'placeholder': 'Confirm new password'}),
        strip=False,
    )
