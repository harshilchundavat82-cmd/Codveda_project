from cryptography.fernet import Fernet

def generate_key():
    key = Fernet.generate_key()
    with open("secret.key", "wb") as key_file:
        key_file.write(key)

def load_key():
    with open("secret.key", "rb") as key_file:
        return key_file.read()

def encrypt_file(filename):
    key = load_key()
    fernet = Fernet(key)

    with open(filename, "rb") as file:
        original_data = file.read()

    encrypted_data = fernet.encrypt(original_data)

    encrypted_file = filename + ".encrypted"
    with open(encrypted_file, "wb") as file:
        file.write(encrypted_data)

    print(f"File encrypted successfully: {encrypted_file}")

def decrypt_file(filename):
    key = load_key()
    fernet = Fernet(key)

    with open(filename, "rb") as file:
        encrypted_data = file.read()

    decrypted_data = fernet.decrypt(encrypted_data)

    decrypted_file = filename.replace(".encrypted", "_decrypted.txt")
    with open(decrypted_file, "wb") as file:
        file.write(decrypted_data)

    print(f"File decrypted successfully: {decrypted_file}")

def main():
    if not load_key_exists():
        generate_key()

    while True:
        print("\nFile Encryption/Decryption Menu:")
        print("1. Encrypt File")
        print("2. Decrypt File")
        print("3. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            filename = input("Enter file name to encrypt: ")
            encrypt_file(filename)

        elif choice == "2":
            filename = input("Enter encrypted file name: ")
            decrypt_file(filename)

        elif choice == "3":
            print("Exiting program...")
            break

        else:
            print("Invalid choice!")

def load_key_exists():
    try:
        open("secret.key", "rb")
        return True
    except FileNotFoundError:
        return False

if __name__ == "__main__":
    main()