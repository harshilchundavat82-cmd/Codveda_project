def Addition(a,b):
    return a + b

def Subtraction(a,b):
    return a - b

def Multiplication(a,b):
    return a * b

def Division(a,b):
    if b == 0:
        return "Error: Division by zero"
    return a / b

try:
    a = int(input("Enter first number: "))
    b = int(input("Enter second number: "))

    print("Select operation:")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    choice = input("Enter choice (1/2/3/4): ")

    if choice == '1':
        print(f"{a} + {b} = {Addition(a, b)}")
    elif choice == '2':
        print(f"{a} - {b} = {Subtraction(a, b)}")
    elif choice == '3':
        print(f"{a} * {b} = {Multiplication(a, b)}")
    elif choice == '4':
        print(f"{a} / {b} = {Division(a, b)}")
    else:
        print("Invalid choice. Please select a valid operation.")

except ValueError:
    print("Invalid input. Please enter numeric values.")
    exit()




