def word_counter(filename):
    try:
        with open(filename, "r") as file:
            content = file.read()

        words = content.split()

        num_words = len(words)

        print(f"Total number of words in '{filename}': {num_words}")

    except FileNotFoundError:
        print(f"Error: The file '{filename}' was not found.")
    except Exception as e:
        print(f"An unexpected error occurred: {e}")

filename = input("Enter the filename: ")
word_counter(filename)
