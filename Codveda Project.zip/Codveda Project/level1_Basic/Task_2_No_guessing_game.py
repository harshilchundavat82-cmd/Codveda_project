import random

secret_no = random.randint(1, 100)
attempts = 5

print("Welcome to the number guessing game!")
print(f"You have {attempts} attempts to guess the secret number between 1 and 100.")

for i in range(attempts):
    try:
        guess = int(input(f"Attempt {i+1}: Enter your guess:"))

        if guess == secret_no:
            print(f"Congratulations! You've guessed the secret number {secret_no} correctly!")
            break
        elif guess < secret_no:
            print("Your guess is too low.")
        else:
            print("Your guess is too high.")
    except ValueError:              
        print("Invalid input. Please enter a numeric value.")

else:
    print(f"Sorry, you've used all your attempts. The secret number was {secret_no}.")
    