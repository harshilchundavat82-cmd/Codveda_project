import requests

def get_crypto_prices():
    url = "https://api.coingecko.com/api/v3/simple/price?ids=bitcoin,ethereum,dogecoin&vs_currencies=usd"

    parameters = {
        "ids": "bitcoin,ethereum,dogecoin",
        "vs_currencies": "usd"
    }

    try:
        response = requests.get(url, params=parameters)

        response.raise_for_status()

        data = response.json()

        print("\nCryptocurrency Prices")
        print(f"Bitcoin  : ${data['bitcoin']['usd']}")
        print(f"Ethereum : ${data['ethereum']['usd']}")
        print(f"Dogecoin : ${data['dogecoin']['usd']}")

    except requests.exceptions.ConnectionError:
        print("Error: Unable to connect to the API.")

    except requests.exceptions.Timeout:
        print("Error: Request timed out.")

    except requests.exceptions.HTTPError as e:
        print(f"HTTP Error: {e}")

    except KeyError:
        print("Error: Unexpected API response format.")

    except Exception as e:
        print(f"An unexpected error occurred: {e}")

get_crypto_prices()