import requests
from bs4 import BeautifulSoup
import csv


url = "https://quotes.toscrape.com/"

try:
    response = requests.get(url)
    response.raise_for_status()
    soup = BeautifulSoup(response.text, "html.parser")
    quotes = soup.find_all("span", class_="text")

    with open("quotes.csv", "w", newline="", encoding="utf-8") as file:
        writer = csv.writer(file)

        writer.writerow(["Quote"])

        for quote in quotes:
            writer.writerow([quote.text])

    print("Data scraped successfully!")
    print("Saved to quotes.csv")

except requests.exceptions.RequestException as e:
    print("Error fetching website:")
    print(e)

except Exception as e:
    print("An error occurred:")
    print(e)