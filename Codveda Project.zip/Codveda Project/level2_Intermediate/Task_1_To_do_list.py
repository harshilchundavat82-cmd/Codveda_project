import csv
import os

FILE_NAME = "tasks.csv"

def initialize_file():
    if not os.path.exists(FILE_NAME):
        with open(FILE_NAME, mode="w", newline="") as file:
            writer = csv.writer(file)
            writer.writerow(["Task", "Completed"])

def load_tasks():
    tasks = []

    initialize_file()

    with open(FILE_NAME, mode="r", newline="") as file:
        reader = csv.DictReader(file)

        for row in reader:
            tasks.append({
                "task": row["Task"],
                "completed": row["Completed"] == "True"
            })

    return tasks

def save_tasks(tasks):
    with open(FILE_NAME, mode="w", newline="") as file:
        writer = csv.writer(file)

        writer.writerow(["Task", "Completed"])

        for task in tasks:
            writer.writerow([task["task"], task["completed"]])

def add_task(task_name):
    tasks = load_tasks()

    tasks.append({
        "task": task_name,
        "completed": False
    })

    save_tasks(tasks)
    print("Task added successfully!")

def view_tasks():
    tasks = load_tasks()

    if not tasks:
        print("No tasks found.")
        return

    print("\n===== TO-DO LIST =====")

    for i, task in enumerate(tasks, start=1):
        status = "Done" if task["completed"] else "Pending"
        print(f"{i}. {task['task']} - {status}")

    print()

def delete_task(task_number):
    tasks = load_tasks()

    if task_number < 1 or task_number > len(tasks):
        print("Error: Task does not exist.")
        return

    removed_task = tasks.pop(task_number - 1)

    save_tasks(tasks)
    print(f"Deleted task: {removed_task['task']}")

def mark_completed(task_number):
    tasks = load_tasks()

    if task_number < 1 or task_number > len(tasks):
        print("Error: Task does not exist.")
        return

    tasks[task_number - 1]["completed"] = True

    save_tasks(tasks)
    print("Task marked as completed.")

def main():
    initialize_file()

    while True:
        print("\nTO-DO LIST MENU")
        print("1. Add Task")
        print("2. View Tasks")
        print("3. Delete Task")
        print("4. Mark Task as Completed")
        print("5. Exit")

        choice = input("Enter your choice: ")

        if choice == "1":
            task_name = input("Enter task: ").strip()

            if task_name:
                add_task(task_name)
            else:
                print("Task cannot be empty.")

        elif choice == "2":
            view_tasks()

        elif choice == "3":
            try:
                task_number = int(input("Enter task number to delete: "))
                delete_task(task_number)
            except ValueError:
                print("Please enter a valid number.")

        elif choice == "4":
            try:
                task_number = int(input("Enter task number to mark as completed: "))
                mark_completed(task_number)
            except ValueError:
                print("Please enter a valid number.")

        elif choice == "5":
            print("Thank you for using the To-Do List Application!")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()